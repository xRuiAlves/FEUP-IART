Versão de python utilizada: 
Python 3.6

Pacotes necessários:
tkinter

Como correr o programa:
python3 main.py

Utilização:
- Navegar nos menus escolhendo a opção desejada
- Selecionar um puzzle à escolha ou carregar um puzzle através de um ficheiro de texto
- Ao selecionar um puzzle, é mostrada uma pré-visualização do mesmo no ecrã
- Selecionar o algorítmo desejado
- Após o algorítmo ser executado, é mostrada a solução alcançada no ecrã
